# sendgrid-nodejs-example

This is an example of using the [SendGrid nodejs library](https://github.com/sendgrid/sendgrid-nodejs).

## Usage

```bash
git clone http://github.com/scottmotte/sendgrid-nodejs-example.git
cd sendgrid-nodejs-example
cp .env.example .env # change the values in .env
npm install
node sendgrid-nodejs-example.js
```
