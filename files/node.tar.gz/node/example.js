var http = require('http');
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Hello World\n');
}).listen(1337, '172.31.30.85');
console.log('Server running at http://172.31.30.85:1337/');
