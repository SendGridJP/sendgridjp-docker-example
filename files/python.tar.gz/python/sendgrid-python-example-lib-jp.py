import sendgrid

# make a secure connection to SendGrid
#s = sendgrid.Sendgrid('sgx2r4h4@kke.com', '111111', secure=True)
s = sendgrid.Sendgrid('awwa500', 'nishion123', secure=True)

# make a message object
message = sendgrid.Message("awwa500@gmail.com", "message subject", "plaintext message body",
    "あいうえおHTML message body")
# add a recipient
message.add_to("awwa500@gmail.com", "Wataru Sato")

# add file
message.add_attachment("example.txt", "./example.txt")

# add cc
message.add_cc("awwa502@gmail.com")

# add bcc
message.add_bcc("awwa501@gmail.com")

# use the Web API to send your message
s.web.send(message)
#s.smtp.send(message)

