#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sendgrid

# make a secure connection to SendGrid
#s = sendgrid.Sendgrid('sgx2r4h4@kke.com', '111111', secure=True)
s = sendgrid.Sendgrid('awwa500', 'nishion123', secure=True)

# make a message object
message = sendgrid.Message("awwa500@gmail.com", "あいうえおmessage subject", "あいうえおplaintext message body -body-",
    "あいうえおHTML message body -body- ")
# add a recipient
message.add_to("awwa500@gmail.com", "Wataru Sato")
message.add_to("awwa501@gmail.com", "Wataru Sato2")

# add file
message.add_attachment("example.txt", "./example.txt")

# add cc
message.add_cc("awwa502@gmail.com")

# add bcc
message.add_bcc("awwa501@gmail.com")

message.add_category("あいうえお")
message.add_section("-section-", "あたい")
message.add_substitution("-body-", "ぼでぃ1")
#s.add_substitution("-body-", "ぼぢぃ2")
# use the Web API to send your message
s.web.send(message)
#s.smtp.send(message)

