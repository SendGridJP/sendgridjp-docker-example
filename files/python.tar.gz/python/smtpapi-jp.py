#!/usr/bin/env python
# -*- coding: utf-8 -*-

from smtpapi import SMTPAPIHeader

header = SMTPAPIHeader()

header.add_substitution('key', 'value')
header.add_substitution('key', 'あいうえお')

print header.json_string()
