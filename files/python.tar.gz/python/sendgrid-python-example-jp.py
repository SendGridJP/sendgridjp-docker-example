#! /usr/bin/python
# -*- coding: utf-8 -*-

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Your From email address
fromEmail = "awwa500@gmail.com"
# Recipient
toEmail = "awwa500@gmail.com"

# Create message container - the correct MIME type is multipart/alternative.
msg = MIMEMultipart('alternative')
msg['Subject'] = "Example Python Email"
msg['From'] = fromEmail
msg['To'] = toEmail

# Create the body of the message (a plain-text and an HTML version).
# text is your plain-text email
# html is your html version of the email
# if the reciever is able to view html emails then only the html
# email will be displayed
text = "こんにちは!\nHow are you?\n"
html = """\n
<html>
  <head></head>
  <body>
    こんにちは!<br>
       How are you?<br>
    
  </body>
</html>
"""

# Login credentials
username = 'awwa500'
password = "nishion123"

# Record the MIME types of both parts - text/plain and text/html.
part1 = MIMEText(text, 'plain')
part2 = MIMEText(html, 'html')

# Attach parts into message container.
msg.attach(part1)
msg.attach(part2)

# Open a connection to the SendGrid mail server
s = smtplib.SMTP('smtp.sendgrid.net', 587)

# Authenticate
s.login(username, password)

# sendmail function takes 3 arguments: sender's address, recipient's address
# and message to send - here it is sent as one string.
s.sendmail(fromEmail, toEmail, msg.as_string())

s.quit()

