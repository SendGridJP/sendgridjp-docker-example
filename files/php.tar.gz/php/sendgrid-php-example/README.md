# sendgrid-php-example

This is an example of using the [SendGrid php library](https://github.com/sendgrid/sendgrid-php).

## Usage

```bash
git clone http://github.com/scottmotte/sendgrid-php-example.git
cd sendgrid-php-example
cp .env.example .env # change the values in .env
composer install
php -f sendgrid-php-example.php
```
