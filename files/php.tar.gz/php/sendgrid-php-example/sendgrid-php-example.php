<?php
require 'vendor/autoload.php';
Dotenv::load(__DIR__);

#$sendgrid_username = $_ENV['SENDGRID_USERNAME'];
#$sendgrid_password = $_ENV['SENDGRID_PASSWORD'];
#$to                = $_ENV['TO'];
$sendgrid_username = "awwa500";
$sendgrid_password = "nishion123";
$to                = "wataru@kke.co.jp";

$sendgrid = new SendGrid($sendgrid_username, $sendgrid_password);
$email    = new SendGrid\Email();
$body = <<<EOD
あいうえお
マグロ
ファイアー
EOD;
$email->addTo($to)->
       setFrom($to)->
       setSubject('[sendgrid-php-example] Owl')->
	setText($body)->
#       setText("こんにちはOwl are you doing?\n開業しました")->
       setHtml('<strong>%how% are you doing?こんにちは</strong>')->
       addSubstitution("%how%", array("Owl"))->
       addMessageHeader('X-Sent-Using', 'SendGrid-API')->
       addMessageHeader('X-Transport', 'web')->
       addAttachment('./gif.gif', 'owl.gif');

$response = $sendgrid->web->send($email);
var_dump($response);
