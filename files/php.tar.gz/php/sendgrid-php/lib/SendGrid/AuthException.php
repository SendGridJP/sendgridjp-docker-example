<?php

namespace SendGrid;

class AuthException extends \Exception { }
