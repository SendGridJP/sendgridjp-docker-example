<?php

namespace SendGrid;

// WARNING: Mail class is deprecated in favor of Email class. 
// This file exists SOLELY for backwards compatibility.
class Mail extends Email {}
